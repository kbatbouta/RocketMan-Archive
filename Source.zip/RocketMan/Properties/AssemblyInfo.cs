﻿
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

// General Information
[assembly: AssemblyTitle("RocketMan")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("STEAM_BUILD")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version informationr(
[assembly: AssemblyVersion("0.6.3.1626")]
[assembly: AssemblyFileVersion("0.6.3.1626")]
[assembly: NeutralResourcesLanguageAttribute( "en-US" )]


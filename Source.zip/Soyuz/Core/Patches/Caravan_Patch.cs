﻿using System;
using RimWorld.Planet;

namespace Soyuz
{
    // TODO:
    //[SoyuzPatch(typeof(Caravan), nameof(Caravan.AddPawn))]
    //public static class Caravan_Notify_PawnAdded_Patch
    //{
    //
    //}
}
